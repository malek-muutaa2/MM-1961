create view neon_backend_perf_counters(procno, pid, metric, bucket_le, value) as
SELECT procno,
       pid,
       metric,
       bucket_le,
       value
FROM neon.get_backend_perf_counters() p(procno integer, pid integer, metric text, bucket_le double precision,
                                        value double precision);

alter table neon_backend_perf_counters
    owner to cloud_admin;

