create view neon_perf_counters(metric, bucket_le, value) as
SELECT metric,
       bucket_le,
       value
FROM neon.get_perf_counters() p(metric text, bucket_le double precision, value double precision);

alter table neon_perf_counters
    owner to cloud_admin;

