create function notify_new_notification() returns trigger
    language plpgsql
as
$$
DECLARE
  payload TEXT;
BEGIN
  payload = row_to_json(NEW)::text;
  PERFORM pg_notify('notifications', payload);
  RETURN NEW;
END;
$$;

alter function notify_new_notification() owner to neondb_owner;

